﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using DAL;

namespace BLL
{
    class UserInfoBLL
    {
       

        public static int AddUser(UserInfoModel model)
        {
            UserInfoDAL userdal = new UserInfoDAL();
            return userdal.AddUser(model);
        }
    }
}
