﻿using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public  class NewsBLL
    {
       //完成对数据的增加
       public static int AddNew(NewsModel model)
       {
           NewsDAL newsdal = new NewsDAL();
           return newsdal.AddNews(model);
       }

       //完成对数据的删除
       public static int Delete(int i)
       {
           NewsDAL newsdal = new NewsDAL();
           return newsdal.delNews(i);
       }
       
       //返回新闻的分类
       public static NewsModel GetModel(int intType)
       {
           NewsModel model = new NewsModel();
           if (intType == 1)
           {
               model.Categories = "外部新闻";
           }
           else if (intType == 2)
           {
               model.Categories="内部新闻";
           }

           return model;
       }

       public static DataRowCollection GetNews()  //查询首页前10条新闻
       {           
           return NewsDAL.GetNews();
       }

       public static DataRowCollection GetNews1()  //查询首页第11-20条新闻
       {
           return NewsDAL.GetNews1();
       }


       public static DataRowCollection GetoneNews(int id)    //查询单条新闻(传入要查询的新闻的id)
       {        
           return NewsDAL.GetoneNews(id);
       }
    }
}
