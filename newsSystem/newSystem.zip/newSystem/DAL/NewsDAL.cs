﻿using Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;

namespace DAL
{
  public   class NewsDAL
    {
      public int AddNews(NewsModel model)
      {
          string sql = "insert into News (title,content,type,author) values(@title,@content,@type,@author)";
          
          int nResult = DBHelper.ExecuteNonQuery(sql, new SqlParameter("@title", model.Title), new SqlParameter("@content", model.Content),  new SqlParameter("@type", model.Type), new SqlParameter("@author", model.Author));

          return nResult;

         // Parameters
          
      }

      public int delNews(int id)
      {
          string sql = "delete from News where id=@id";
          int nResult = DBHelper.ExecuteNonQuery(sql, new SqlParameter("@id", id));
          return nResult;
      }

      public int UpdateNews(NewsModel model, int nid)
      {
          string sql = "update News set title=@title,content=@content,categories=@categories,type=@type where id=" + nid;

          int nResult = DBHelper.ExecuteNonQuery(sql, new SqlParameter("@title", model.Title), new SqlParameter("@content", model.Content), new SqlParameter("@categories", model.Categories), new SqlParameter("@type", model.Type));
         return nResult;
      }



      public static DataRowCollection GetNews()    //首页前10条新闻
      {
          string selectSql = "select top 10* from News order by issueDate desc ";
          DataTable lb = DBHelper.GetDataTable(selectSql);
          return lb.Rows;
      }


      public static DataRowCollection GetNews1()     //首页第11-20条新闻
      {
          string selectSql = "select top 10* from News where id not in (select top 10 id from News order by issueDate desc) order by issueDate desc ";
          DataTable lb = DBHelper.GetDataTable(selectSql);
          return lb.Rows;
      }

      public static DataRowCollection GetoneNews(int id)    //查询单条新闻(传入要查询的新闻的id)
      {
          string selectSql = "select * from News where id =@id";
          SqlParameter[] parm = { new SqlParameter("@id", SqlDbType.Int) };
          parm[0].Value = id;
          DataTable dt = DBHelper.ExecuteDataTable(selectSql,parm);                   
          return dt.Rows;
      }

    




      ////执行数据库的查询操作
      //public NewsModel[] GetNewsModel()//声明一次从数据库中读取新闻的条数
      //{
      //    NewsModel[] model;
      //    string sql = "select * from News ";
      //    DataTable dt = DBHelper.ExecuteDataTable(sql);
         
      //    if (dt.Rows.Count >0)
      //    {
      //        NewsModel item = new NewsModel();
      //        DataRow dr = dt.Rows[0];
      //        model.Title = dr["title"].ToString();
      //        model.Content = dr["content"].ToString();
      //        //  model.Categories = Convert.ToInt32(dr["categories"].ToString());
      //        model.Type = dr["type"].ToString();
      //    }
      //    else if (dt.Rows.Count == 1)
      //    {
      //        NewsModel model = new NewsModel();
      //        DataRow dr = dt.Rows[0];
      //        model.Title = dr["title"].ToString();
      //        model.Content = dr["content"].ToString();
      //      //  model.Categories = Convert.ToInt32(dr["categories"].ToString());
      //        model.Type = dr["type"].ToString();
          

      //        return model;
      //    }
      //    else
      //        throw new Exception("出现异常");
      //}
        
        }
    

}
