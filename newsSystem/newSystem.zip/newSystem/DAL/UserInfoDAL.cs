﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data.SqlClient;


namespace DAL
{
   public  class UserInfoDAL
    {
     
        public int AddUser(UserInfoModel model)
        {
            string sql = "insert into UserInfo(userID, username,password)values(@userID,@username,@password)";
            int nResult=DBHelper.ExecuteNonQuery(sql,new SqlParameter("@userID",model.UserID),new SqlParameter ("@username",model.Username),new SqlParameter("@password",model.Password));
            return nResult;
        }

        public int DelectUser(int id)
        {
            string sql = "delect from UserInfo where id=" + id;
            int nResult = DBHelper.ExecuteNonQuery(sql, new SqlParameter("@id", id));
            return nResult;
        }
    }
}
