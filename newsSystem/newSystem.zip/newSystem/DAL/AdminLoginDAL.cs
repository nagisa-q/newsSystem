﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Collections;
using System.Data;
using Model;
using System.Configuration;


namespace DAL
{
    public class AdminLoginDAL
    {
        //获取数据库连接字符串
      static  string connString = ConfigurationManager.ConnectionStrings["SQLConnectionString"].ConnectionString;

        public static List<User> GetUserInfo(string name, string password)
        {
            List<User> Users = new List<User>();
            string sql = "select * from AdminLogin where psw = '" + password + "' and name = '" + name + "'"; //写where子句的时候把Password放前面.因为Password经过加密,所以可以防止SQL注入攻击
            SqlDataAdapter da = new SqlDataAdapter(sql, connString);
            DataSet ds = new DataSet();
            da.Fill(ds);

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                User admo = new User(ds.Tables[0].Rows[i]["ID"].ToString(), ds.Tables[0].Rows[i]["User"].ToString(), ds.Tables[0].Rows[i]["Password"].ToString());
                Users.Add(admo);
            }

            return Users;
        }
      
    }
}
         
       
