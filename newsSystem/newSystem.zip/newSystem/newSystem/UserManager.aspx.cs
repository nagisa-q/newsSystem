﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Model;

namespace NewFram
{
    public partial class UserManager : System.Web.UI.Page
    {
          //获取数据库连接字符串
       public static string connString = ConfigurationManager.ConnectionStrings["SQLConnectionString"].ConnectionString;
          public void BindData()
        {
            string cmdText = "select * from info ";
            SqlConnection con = new SqlConnection(connString);

            SqlDataAdapter sda = new SqlDataAdapter(cmdText, con);
            DataSet dt = new DataSet();
            sda.Fill(dt);
            this.GridView1.DataSource = dt.Tables[0];
            this.GridView1.DataBind();
        }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
               SqlConnection con = new SqlConnection(connString);
            int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);/*获取主键，需要设置 DataKeyNames，这里设为 id */
            String sql = "delete from info where id='" + id + "'";

            SqlCommand com = new SqlCommand(sql, con);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            BindData();
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
              GridView1.PageIndex = e.NewPageIndex;
        }

        protected void GridView1_PageIndexChanged(object sender, EventArgs e)
        {
            BindData();
        }

        protected void GridView1_DataBound(object sender, EventArgs e)
        {
            //添加分页码显示
            GridViewRow bottomPagerRow = GridView1.BottomPagerRow;
            Label bottomLabel = new Label();
            bottomLabel.Text = "目前所在分页：（" + (GridView1.PageIndex + 1) + "/" + GridView1.PageCount + "）";
            bottomPagerRow.Cells[0].Controls.Add(bottomLabel);
        }

        protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
        {
            //这是稳妥的设定gridview字体的方法
            GridView1.Font.Size = 10;
            //这个是控制每行的列宽.
            GridView1.RowStyle.Height = 50;
            //这个是控制每列的宽度，可以根据需要设置更多的列
            GridView1.Columns[0].ItemStyle.Width = 50;
            GridView1.Columns[1].ItemStyle.Width = 100;
            GridView1.Columns[2].ItemStyle.Width = 150;
            //GridView1.Columns[3].ItemStyle.Width = 100;
            //GridView1.Columns[4].ItemStyle.Width = 100;
            //GridView1.Columns[5].ItemStyle.Width = 100;
        }

       }
    }
