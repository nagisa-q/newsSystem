﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;

namespace newSystem
{
    public partial class newsContent : System.Web.UI.Page
    {
        public DataRowCollection drow2;  
        protected void Page_Load(object sender, EventArgs e)
        {
           // 到时候在新闻页面的这里写
            string nid = Request.QueryString["id"];
            int id;
            int.TryParse(nid, out id);
            if (id > 0)
            {
                drow2 = NewsBLL.GetoneNews(id);
            }
        }
    }
}