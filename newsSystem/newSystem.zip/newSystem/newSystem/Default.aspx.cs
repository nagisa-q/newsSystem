﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Model;
using BLL;
using System.Data;

namespace newSystem
{
    public partial class Default : System.Web.UI.Page 
      
       
    {
        public NewsModel[] model;
        public DataRowCollection drow;  //前10
        public DataRowCollection drow1;  //11-20
       
        protected void Page_Load(object sender, EventArgs e)
        {
            drow = NewsBLL.GetNews();
            drow1 = NewsBLL.GetNews1();   
            //到时候在新闻页面的这里写
            //string nid = Request.QueryString["id"];
            //int id;
            //int.TryParse(nid, out id);
            //if (id > 0)
            //{
            //    drow2 = NewsBLL.GetoneNews(id);
            //}
        }

        protected void Unnamed1_Click(object sender, EventArgs e)
        {
           
        }

       

    }
}