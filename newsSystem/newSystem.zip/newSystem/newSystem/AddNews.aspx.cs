﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Model;
using BLL;


namespace newSystem
{
    public partial class AddNews : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            InsertData();
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {

        }

        public void InsertData()
        {
            NewsModel model = new NewsModel();
            model.Title = this.txtNewsTitle.Text;
            model.Content = this.txtNewsContent.Text;
            model.Author = this.txtZuozhe.Text;
            model.Type = this.dlstNewsType.Text;
            int nReault = NewsBLL.AddNew(model);
           
            if (nReault == 1)
            {
               // Response.Write("<script>alert('添加成功')<script>");
                Page.ClientScript.RegisterStartupScript(GetType(), "TOM", "<script>alert('添加成功');</script>");
                //Response.Write(nReault);
            }
            else
                Page.ClientScript.RegisterStartupScript(GetType(), "TOM", "<script>alert('添加失败');</script>");
        }
    }
}