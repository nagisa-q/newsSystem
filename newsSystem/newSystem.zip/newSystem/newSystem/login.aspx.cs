﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace newSystem
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void buttom_Click(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {


            Label1.Text = "";
            //获取数据库连接字符串
            string connString = ConfigurationManager.ConnectionStrings["SQLConnectionString"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // 定义SQL语句，@Admin 表示这是一个占位符，@Password表示这是另外一个占位符
                string sql = "select * from UserInfo where username = @AdminName and password = @Password";
                SqlCommand cmd = new SqlCommand(sql, conn);
                // 把TextBox1的输入框的内容赋值给@Admin占位符
                cmd.Parameters.AddWithValue("@AdminName", tbusername.Text);
                // 把TextBox2的输入框的内容赋值给@Password占位符
                cmd.Parameters.AddWithValue("@Password", tbpsw.Text);
                conn.Open();
                // 赋值完成之后，sql就是一条完整的查询语句
                SqlDataReader rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    // 如果有记录，说明用户名和密码正确
                    // 把用户名放入Session中暂存起来，同时给它一个标识符 AdminName
                    Session.Add("AdminName", tbusername.Text);
                    // 把用户ID放入Session中暂存起来，同时给它一个标识符 AdminID
                    Session.Add("AdminID", rd["userID"].ToString());
                    // 把用户权限放入Session中暂存起来，同时给它一个标识符 Purview
                    //Session.Add("Purview", rd["Purview"].ToString());
                    // 登录成功，跳转到后台的管理员管理页面
                    Response.Redirect("Default.aspx");
                }
                else
                {
                    // 用户名和密码不匹配，提示出错信息
                    Label1.Text = "用户名或密码错误，请重新输入！";
                }
            }

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            string username = tbusername.Text;
            string password = tbpsw.Text;
            string sql = "Insert into UserInfo(username, password) values(@username,@password)";
            SqlParameter[] parameters = { new SqlParameter("@username", username), new SqlParameter("@password", password) };
            string connString = ConfigurationManager.ConnectionStrings["SQLConnectionString"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.AddRange(parameters);
                    cmd.ExecuteNonQuery();
                }
            }

            Response.Write(@"<script>alert('注册成功！请登录！');</script>");  
        }
    }
}
