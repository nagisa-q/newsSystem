﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using DAL;
using Model;
using System.Data.OleDb;
using System.Data;
using System.Data.SqlClient;



namespace NewFram
{
    public partial class ManagerNew : System.Web.UI.Page
    {
        //获取数据库连接字符串
       public static string connString = ConfigurationManager.ConnectionStrings["SQLConnectionString"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) /*如果省略这句，下面的更新操作将无法完成，因为获得的值是不变的*/
            {
                BindData();
            }
          
        }
        public void BindData()
        {
            string cmdText = "select * from News ";
            SqlConnection con = new SqlConnection(connString);

            SqlDataAdapter sda = new SqlDataAdapter(cmdText, con);
            DataSet dt = new DataSet();
            sda.Fill(dt);
            this.GridView1.DataSource = dt.Tables[0];
            this.GridView1.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {

        }

        protected void gvdNews_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

            SqlConnection con = new SqlConnection(connString);
            int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);/*获取主键，需要设置 DataKeyNames，这里设为 id */
            String sql = "delete from News where id='" + id + "'";

            SqlCommand com = new SqlCommand(sql, con);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            BindData();
           
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
        }

        protected void GridView1_PageIndexChanged(object sender, EventArgs e)
        {
            BindData();
        }

        protected void GridView1_DataBound(object sender, EventArgs e)
        {
            //添加分页码显示
            GridViewRow bottomPagerRow = GridView1.BottomPagerRow;
            Label bottomLabel = new Label();
            bottomLabel.Text = "目前所在分页：（" + (GridView1.PageIndex + 1) + "/" + GridView1.PageCount + "）";
            bottomPagerRow.Cells[0].Controls.Add(bottomLabel);
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            BindData();    
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            NewsModel model = new NewsModel();
           
            SqlConnection con = new SqlConnection(connString);
          
          //  String title = (GridView1.Rows[e.RowIndex].Cells[1].Controls[0] as TextBox).Text.ToString();    /*获取要更新的数据*/
          //  String content = (GridView1.Rows[e.RowIndex].Cells[2].Controls[0] as TextBox).Text.ToString();
          //  String type = (GridView1.Rows[e.RowIndex].Cells[3].Controls[0] as TextBox).Text.ToString();
          //  String author = (GridView1.Rows[e.RowIndex].Cells[4].Controls[0] as TextBox).Text.ToString();
          ////  String issuedate = (GridView1.Rows[e.RowIndex].Cells[6].Controls[0] as TextBox).Text.ToString();
          //  int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);/*获取主键，需要设置 DataKeyNames，这里设为 id */

            string sql = "update News set title='" + ((TextBox)(GridView1.Rows[e.RowIndex].Cells[2].Controls[0])).Text.ToString().Trim() + "',content='" + ((TextBox)(GridView1.Rows[e.RowIndex].Cells[3].Controls[0])).Text.ToString().Trim() + "',type='" + ((TextBox)(GridView1.Rows[e.RowIndex].Cells[4].Controls[0])).Text.ToString().Trim() + "' where id='" + GridView1.DataKeys[e.RowIndex].Value.ToString() + "'";





           // String sql = "update News set title='" + model.Title + "',content='" + model.Content + "',type='" + model.Type + "',author='" + model.Author + "' where id='" + id + "'";

            SqlCommand com = new SqlCommand(sql, con);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            GridView1.EditIndex = -1;
            BindData();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;                 /*编辑索引赋值为-1，变回正常显示状态*/
            BindData();
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //foreach (Table tc in e.Row.Cells)
            //{
            //    tc.Attributes["style"] = "width:100px";
            //}
        }

        protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
        {
            //这是稳妥的设定gridview字体的方法
            GridView1.Font.Size = 10;
            //这个是控制每行的列宽.
            GridView1.RowStyle.Height = 50;
            //这个是控制每列的宽度，可以根据需要设置更多的列
            GridView1.Columns[0].ItemStyle.Width = 50;
            GridView1.Columns[1].ItemStyle.Width = 100;
            GridView1.Columns[2].ItemStyle.Width = 150;
            GridView1.Columns[3].ItemStyle.Width = 100;
            GridView1.Columns[4].ItemStyle.Width = 100;
            GridView1.Columns[5].ItemStyle.Width = 100;
            //GridView1.Columns[6].ItemStyle.Width = 100;
        }

        protected void searchbtn_Click(object sender, EventArgs e)
        {
            if (txtsearch.Text == "")
            {
                lbMsg.Text = "请输入查询";
                this.GridView1.DataBind();

            }
            else
            {
                lbMsg.Visible = false;
                SqlConnection con = new SqlConnection(connString);
                string str = "select * from News where title like '%" + txtsearch.Text + "%'";
                SqlDataAdapter da = new SqlDataAdapter(str, con);
                DataSet ds = new DataSet();
                try
                {
                    da.Fill(ds, "tt");
                    if (ds.Tables["tt"].Rows.Count != 0)
                    {
                        this.GridView1.DataSource = ds.Tables["tt"].DefaultView;
                        this.GridView1.DataBind();
                    }
                    else
                    {
                        Response.Write("<script>alert('no record!')</script>");
                    }
                }
               catch(Exception ex){
                   throw new Exception (ex.Message);
               }
                }
            }
        }
    }
