﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
   public  class User
    {
        string ID;
        string name;
        string Password;

        //重载构造函数
      public   User(string id, string user, string password)
        {
            this.ID = id;
            this.name = user;
            this.Password = password;
        }
    }
}
